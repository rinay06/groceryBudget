package com.example.GroceryPlanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroceryPlannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroceryPlannerApplication.class, args);
	}

}
