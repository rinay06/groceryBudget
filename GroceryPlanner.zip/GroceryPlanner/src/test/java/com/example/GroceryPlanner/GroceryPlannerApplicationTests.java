package com.example.GroceryPlanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
